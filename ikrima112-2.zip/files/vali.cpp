#include <iostream>
#include <vector>
#include <sstream>

bool validate_input(std::vector<std::string>& lines) {
    // Validate the number of test cases
    int t = std::stoi(lines[0]);
    if (!(1 <= t && t <= 10000)) {
        std::cerr << "Invalid number of test cases: t must be between 1 and 10000" << std::endl;
        return false;
    }

    // Validate each test case
    for (int i = 1; i < lines.size(); i += 3) {
        // Validate the number of players and goalkeepers
        int n = std::stoi(lines[i]);
        if (!(2 <= n && n <= 500)) {
            std::cerr << "Invalid number of players and goalkeepers: n must be between 2 and 500" << std::endl;
            return false;
        }

        // Validate the player ratings
        std::istringstream iss_p(lines[i + 1]);
        int rating;
        while (iss_p >> rating) {
            if (!(1 <= rating && rating <= 500)) {
                std::cerr << "Invalid player rating: PR_i must be between 1 and 500" << std::endl;
                return false;
            }
        }

        // Validate the goalkeeper ratings
        std::istringstream iss_g(lines[i + 2]);
        while (iss_g >> rating) {
            if (!(1 <= rating && rating <= 500)) {
                std::cerr << "Invalid goalkeeper rating: GR_i must be between 1 and 500" << std::endl;
                return false;
            }
        }
    }

    return true;
}

int main() {
    // Read input data from stdin
    std::vector<std::string> input_lines;
    std::string line;
    while (std::getline(std::cin, line)) {
        input_lines.push_back(line);
    }

    // Validate the input
    if (validate_input(input_lines)) {
        std::cout << 1 << std::endl;
    } else {
        std::cout << 0 << std::endl;
    }

    return 0;
}
